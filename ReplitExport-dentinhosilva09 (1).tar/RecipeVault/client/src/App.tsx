import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { BottomNav } from "@/components/bottom-nav";
import { DesktopNav } from "@/components/desktop-nav";
import Browse from "@/pages/browse";
import AddRecipe from "@/pages/add-recipe";
import RecipeDetail from "@/pages/recipe-detail";
import Categories from "@/pages/categories";
import NotFound from "@/pages/not-found";
import { ChefHat } from "lucide-react";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Browse} />
      <Route path="/add" component={AddRecipe} />
      <Route path="/edit/:id" component={AddRecipe} />
      <Route path="/recipe/:id" component={RecipeDetail} />
      <Route path="/categories" component={Categories} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <div className="min-h-screen bg-background pb-20 md:pb-0">
          <header className="sticky top-0 z-40 bg-background border-b border-border backdrop-blur">
            <div className="container mx-auto px-4 h-16 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-primary rounded-md flex items-center justify-center">
                  <ChefHat className="w-6 h-6 text-primary-foreground" />
                </div>
                <h1 className="text-xl font-bold">Minhas Receitas</h1>
              </div>
              <DesktopNav />
            </div>
          </header>

          <main className="container mx-auto px-4 py-6 md:py-8">
            <Router />
          </main>

          <BottomNav />
        </div>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
