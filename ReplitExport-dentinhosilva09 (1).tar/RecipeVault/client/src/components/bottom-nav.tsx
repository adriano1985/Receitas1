import { BookOpen, Plus, Tags } from "lucide-react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";

export function BottomNav() {
  const [location, setLocation] = useLocation();

  const navItems = [
    { path: "/", icon: BookOpen, label: "Receitas", testId: "mobile-nav-browse" },
    { path: "/add", icon: Plus, label: "Adicionar", testId: "mobile-nav-add" },
    { path: "/categories", icon: Tags, label: "Categorias", testId: "mobile-nav-categories" },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-card border-t border-card-border z-50 md:hidden">
      <div className="flex items-center justify-around h-16 px-4">
        {navItems.map(({ path, icon: Icon, label, testId }) => {
          const isActive = location === path;
          return (
            <Button
              key={path}
              variant="ghost"
              size="sm"
              onClick={() => setLocation(path)}
              className={`flex flex-col items-center gap-1 h-auto py-2 px-4 ${
                isActive ? "text-primary" : "text-muted-foreground"
              }`}
              data-testid={testId}
            >
              <Icon className={`w-6 h-6 ${isActive ? "fill-current" : ""}`} />
              <span className="text-xs font-medium">{label}</span>
            </Button>
          );
        })}
      </div>
    </nav>
  );
}
