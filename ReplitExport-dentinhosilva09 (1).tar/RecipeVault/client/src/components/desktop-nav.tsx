import { BookOpen, Plus, Tags } from "lucide-react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";

export function DesktopNav() {
  const [location, setLocation] = useLocation();

  const navItems = [
    { path: "/", icon: BookOpen, label: "Receitas", testId: "desktop-nav-browse" },
    { path: "/add", icon: Plus, label: "Adicionar", testId: "desktop-nav-add" },
    { path: "/categories", icon: Tags, label: "Categorias", testId: "desktop-nav-categories" },
  ];

  return (
    <nav className="hidden md:flex items-center gap-2">
      {navItems.map(({ path, icon: Icon, label, testId }) => {
        const isActive = location === path;
        return (
          <Button
            key={path}
            variant={isActive ? "secondary" : "ghost"}
            onClick={() => setLocation(path)}
            className="gap-2"
            data-testid={testId}
          >
            <Icon className="w-4 h-4" />
            {label}
          </Button>
        );
      })}
    </nav>
  );
}
