import { ChefHat } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";

interface EmptyStateProps {
  title: string;
  description: string;
  actionLabel?: string;
  onAction?: () => void;
}

export function EmptyState({ title, description, actionLabel, onAction }: EmptyStateProps) {
  const [, setLocation] = useLocation();

  return (
    <div className="flex flex-col items-center justify-center py-16 px-4 text-center" data-testid="empty-state">
      <div className="w-24 h-24 rounded-full bg-muted flex items-center justify-center mb-6">
        <ChefHat className="w-12 h-12 text-muted-foreground" />
      </div>
      <h3 className="text-xl font-semibold mb-2">{title}</h3>
      <p className="text-muted-foreground mb-6 max-w-md">{description}</p>
      {actionLabel && (
        <Button 
          onClick={onAction || (() => setLocation("/add"))}
          data-testid="button-empty-action"
        >
          {actionLabel}
        </Button>
      )}
    </div>
  );
}
