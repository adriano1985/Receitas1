import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ChefHat } from "lucide-react";
import type { Recipe } from "@shared/schema";
import { Link } from "wouter";

interface RecipeCardProps {
  recipe: Recipe;
}

export function RecipeCard({ recipe }: RecipeCardProps) {
  return (
    <Link href={`/recipe/${recipe.id}`}>
      <Card 
        className="overflow-hidden hover-elevate active-elevate-2 cursor-pointer transition-all duration-200 h-full flex flex-col"
        data-testid={`card-recipe-${recipe.id}`}
      >
        <div className="aspect-video bg-muted flex items-center justify-center">
          <ChefHat className="w-12 h-12 text-muted-foreground" />
        </div>
        
        <div className="p-4 flex-1 flex flex-col gap-3">
          <h3 
            className="font-semibold text-lg leading-tight line-clamp-2"
            data-testid={`text-recipe-name-${recipe.id}`}
          >
            {recipe.name}
          </h3>
          
          <div className="flex flex-wrap gap-2 mt-auto">
            {recipe.categories.slice(0, 3).map((category) => (
              <Badge 
                key={category} 
                variant="secondary"
                className="text-xs"
                data-testid={`badge-category-${category}`}
              >
                {category}
              </Badge>
            ))}
            {recipe.categories.length > 3 && (
              <Badge variant="secondary" className="text-xs">
                +{recipe.categories.length - 3}
              </Badge>
            )}
          </div>
        </div>
      </Card>
    </Link>
  );
}
