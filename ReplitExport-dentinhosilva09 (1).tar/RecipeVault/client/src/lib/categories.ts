export const AVAILABLE_CATEGORIES = [
  "Sobremesas",
  "Massas",
  "Carnes",
  "Peixes",
  "Vegetariano",
  "Vegano",
  "Lanches",
  "Saladas",
  "Sopas",
  "Bebidas",
  "Pães",
  "Bolos",
] as const;

export type Category = typeof AVAILABLE_CATEGORIES[number];
