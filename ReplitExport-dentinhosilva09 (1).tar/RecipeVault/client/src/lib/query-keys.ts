export const QUERY_KEYS = {
  recipes: () => ['/api/recipes'] as const,
  recipe: (id: string) => ['/api/recipes', id] as const,
} as const;
