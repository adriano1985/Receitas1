import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useLocation, useRoute } from "wouter";
import { insertRecipeSchema, type InsertRecipe, type Recipe } from "@shared/schema";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { AVAILABLE_CATEGORIES } from "@/lib/categories";
import { QUERY_KEYS } from "@/lib/query-keys";
import { X } from "lucide-react";
import { useEffect } from "react";

export default function AddRecipe() {
  const [, params] = useRoute("/edit/:id");
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const isEditing = !!params?.id;

  const { data: recipe } = useQuery<Recipe>({
    queryKey: QUERY_KEYS.recipe(params?.id || ""),
    enabled: isEditing && !!params?.id,
  });

  const form = useForm<InsertRecipe>({
    resolver: zodResolver(insertRecipeSchema),
    defaultValues: {
      name: "",
      ingredients: "",
      instructions: "",
      categories: [],
    },
  });

  useEffect(() => {
    if (recipe && isEditing) {
      form.reset({
        name: recipe.name,
        ingredients: recipe.ingredients,
        instructions: recipe.instructions,
        categories: recipe.categories,
      });
    }
  }, [recipe, isEditing, form]);

  const createMutation = useMutation({
    mutationFn: (data: InsertRecipe) => 
      apiRequest("POST", "/api/recipes", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: QUERY_KEYS.recipes() });
      toast({
        title: "Sucesso!",
        description: "Receita adicionada com sucesso.",
      });
      setLocation("/");
    },
    onError: () => {
      toast({
        title: "Erro",
        description: "Não foi possível adicionar a receita.",
        variant: "destructive",
      });
    },
  });

  const updateMutation = useMutation({
    mutationFn: (data: InsertRecipe) => 
      apiRequest("PATCH", `/api/recipes/${params?.id}`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: QUERY_KEYS.recipes() });
      queryClient.invalidateQueries({ queryKey: QUERY_KEYS.recipe(params?.id || "") });
      toast({
        title: "Sucesso!",
        description: "Receita atualizada com sucesso.",
      });
      setLocation(`/recipe/${params?.id}`);
    },
    onError: () => {
      toast({
        title: "Erro",
        description: "Não foi possível atualizar a receita.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: InsertRecipe) => {
    if (isEditing) {
      updateMutation.mutate(data);
    } else {
      createMutation.mutate(data);
    }
  };

  const selectedCategories = form.watch("categories");

  const toggleCategory = (category: string) => {
    const current = selectedCategories || [];
    if (current.includes(category)) {
      form.setValue("categories", current.filter((c) => c !== category));
    } else {
      form.setValue("categories", [...current, category]);
    }
  };

  const isPending = createMutation.isPending || updateMutation.isPending;

  return (
    <div className="max-w-2xl mx-auto">
      <div className="mb-6">
        <h1 className="text-2xl md:text-3xl font-bold mb-2">
          {isEditing ? "Editar Receita" : "Nova Receita"}
        </h1>
        <p className="text-muted-foreground">
          {isEditing ? "Atualize os detalhes da sua receita" : "Adicione uma nova receita à sua coleção"}
        </p>
      </div>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <FormField
            control={form.control}
            name="name"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Nome da Receita</FormLabel>
                <FormControl>
                  <Input 
                    placeholder="Ex: Bolo de Chocolate" 
                    className="text-lg"
                    data-testid="input-name"
                    {...field} 
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="categories"
            render={() => (
              <FormItem>
                <FormLabel>Categorias</FormLabel>
                <FormControl>
                  <div className="space-y-3">
                    <div className="flex flex-wrap gap-2">
                      {AVAILABLE_CATEGORIES.map((category) => {
                        const isSelected = selectedCategories?.includes(category);
                        return (
                          <Badge
                            key={category}
                            variant={isSelected ? "default" : "outline"}
                            className="cursor-pointer hover-elevate active-elevate-2"
                            onClick={() => toggleCategory(category)}
                            data-testid={`toggle-category-${category}`}
                          >
                            {category}
                            {isSelected && <X className="ml-1 w-3 h-3" />}
                          </Badge>
                        );
                      })}
                    </div>
                  </div>
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="ingredients"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Ingredientes</FormLabel>
                <FormControl>
                  <Textarea 
                    placeholder="Digite ou cole os ingredientes, um por linha:&#10;- 2 xícaras de farinha&#10;- 1 xícara de açúcar&#10;- 3 ovos"
                    className="min-h-[150px] resize-none font-serif"
                    data-testid="input-ingredients"
                    {...field} 
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="instructions"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Modo de Preparo</FormLabel>
                <FormControl>
                  <Textarea 
                    placeholder="Digite ou cole as instruções:&#10;1. Pré-aqueça o forno a 180°C&#10;2. Misture os ingredientes secos&#10;3. Adicione os ingredientes líquidos..."
                    className="min-h-[200px] resize-none font-serif"
                    data-testid="input-instructions"
                    {...field} 
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <div className="flex gap-3 pt-4">
            <Button
              type="submit"
              className="flex-1"
              disabled={isPending}
              data-testid="button-save"
            >
              {isPending ? "Salvando..." : isEditing ? "Atualizar Receita" : "Salvar Receita"}
            </Button>
            <Button
              type="button"
              variant="outline"
              onClick={() => setLocation(isEditing ? `/recipe/${params?.id}` : "/")}
              disabled={isPending}
              data-testid="button-cancel"
            >
              Cancelar
            </Button>
          </div>
        </form>
      </Form>
    </div>
  );
}
