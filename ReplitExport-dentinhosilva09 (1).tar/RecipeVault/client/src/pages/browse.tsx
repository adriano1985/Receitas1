import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { RecipeCard } from "@/components/recipe-card";
import { EmptyState } from "@/components/empty-state";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";
import { Search } from "lucide-react";
import { AVAILABLE_CATEGORIES } from "@/lib/categories";
import { QUERY_KEYS } from "@/lib/query-keys";
import type { Recipe } from "@shared/schema";

export default function Browse() {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");

  const { data: recipes, isLoading } = useQuery<Recipe[]>({
    queryKey: QUERY_KEYS.recipes(),
  });

  const filteredRecipes = recipes?.filter((recipe) => {
    const matchesCategory = !selectedCategory || recipe.categories.includes(selectedCategory);
    const matchesSearch = !searchQuery || 
      recipe.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      recipe.ingredients.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="space-y-6">
      <div className="space-y-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Buscar receitas..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
            data-testid="input-search"
          />
        </div>

        <div className="flex gap-2 overflow-x-auto pb-2 -mx-4 px-4 md:mx-0 md:px-0">
          <Badge
            variant={selectedCategory === null ? "default" : "outline"}
            className="cursor-pointer whitespace-nowrap hover-elevate active-elevate-2"
            onClick={() => setSelectedCategory(null)}
            data-testid="filter-all"
          >
            Todas
          </Badge>
          {AVAILABLE_CATEGORIES.map((category) => (
            <Badge
              key={category}
              variant={selectedCategory === category ? "default" : "outline"}
              className="cursor-pointer whitespace-nowrap hover-elevate active-elevate-2"
              onClick={() => setSelectedCategory(category)}
              data-testid={`filter-${category}`}
            >
              {category}
            </Badge>
          ))}
        </div>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[...Array(6)].map((_, i) => (
            <div key={i} className="space-y-3">
              <Skeleton className="aspect-video w-full" />
              <Skeleton className="h-6 w-3/4" />
              <div className="flex gap-2">
                <Skeleton className="h-5 w-20" />
                <Skeleton className="h-5 w-20" />
              </div>
            </div>
          ))}
        </div>
      ) : filteredRecipes && filteredRecipes.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredRecipes.map((recipe) => (
            <RecipeCard key={recipe.id} recipe={recipe} />
          ))}
        </div>
      ) : (
        <EmptyState
          title={searchQuery || selectedCategory ? "Nenhuma receita encontrada" : "Nenhuma receita ainda"}
          description={
            searchQuery || selectedCategory
              ? "Tente ajustar os filtros ou buscar por outros termos."
              : "Comece adicionando sua primeira receita."
          }
          actionLabel={searchQuery || selectedCategory ? undefined : "Adicionar Receita"}
        />
      )}
    </div>
  );
}
