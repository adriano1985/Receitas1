import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { AVAILABLE_CATEGORIES } from "@/lib/categories";
import { QUERY_KEYS } from "@/lib/query-keys";
import type { Recipe } from "@shared/schema";
import { useLocation } from "wouter";

export default function Categories() {
  const [, setLocation] = useLocation();
  const { data: recipes, isLoading } = useQuery<Recipe[]>({
    queryKey: QUERY_KEYS.recipes(),
  });

  const categoryCounts = AVAILABLE_CATEGORIES.map((category) => ({
    name: category,
    count: recipes?.filter((recipe) => recipe.categories.includes(category)).length || 0,
  }));

  const handleCategoryClick = (category: string) => {
    setLocation(`/?category=${category}`);
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl md:text-3xl font-bold mb-2">Categorias</h1>
        <p className="text-muted-foreground">
          Explore suas receitas por categoria
        </p>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[...Array(12)].map((_, i) => (
            <Skeleton key={i} className="h-24" />
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {categoryCounts.map(({ name, count }) => (
            <Card
              key={name}
              className="p-6 hover-elevate active-elevate-2 cursor-pointer transition-all duration-200"
              onClick={() => handleCategoryClick(name)}
              data-testid={`card-category-${name}`}
            >
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-semibold text-lg mb-1">{name}</h3>
                  <p className="text-sm text-muted-foreground">
                    {count} {count === 1 ? "receita" : "receitas"}
                  </p>
                </div>
                <Badge variant="secondary" className="text-lg px-3 py-1">
                  {count}
                </Badge>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
