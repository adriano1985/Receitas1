import { sql } from "drizzle-orm";
import { pgTable, text, varchar } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const recipes = pgTable("recipes", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  ingredients: text("ingredients").notNull(),
  instructions: text("instructions").notNull(),
  categories: text("categories").array().notNull().default(sql`ARRAY[]::text[]`),
});

export const insertRecipeSchema = createInsertSchema(recipes).omit({
  id: true,
}).extend({
  name: z.string().min(1, "Nome da receita é obrigatório"),
  ingredients: z.string().min(1, "Ingredientes são obrigatórios"),
  instructions: z.string().min(1, "Modo de preparo é obrigatório"),
  categories: z.array(z.string()).min(1, "Selecione pelo menos uma categoria"),
});

export type InsertRecipe = z.infer<typeof insertRecipeSchema>;
export type Recipe = typeof recipes.$inferSelect;
